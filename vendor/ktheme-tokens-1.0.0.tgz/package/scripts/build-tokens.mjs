import * as fs from 'fs';
import * as path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const packageDir = path.resolve(__dirname, '..');
const kthemeRoot = path.resolve(packageDir, '../..');
const distDir = path.resolve(packageDir, 'dist');
const jsonDistDir = path.resolve(distDir, 'json');
const runtimeThemesDir = path.resolve(kthemeRoot, 'libs/ktheme-runtime/src/main/resources/themes');

if (!fs.existsSync(distDir)) fs.mkdirSync(distDir, { recursive: true });
if (!fs.existsSync(jsonDistDir)) fs.mkdirSync(jsonDistDir, { recursive: true });

// helper for mkPal
const mkPal = (name, c, note, light) => ({ name, note, light: !!light, c });

// 1. PALETTES definition
const PALETTES = {
  ink: mkPal("Ink Terminal", { bg:"#0A1112", surf:"#101A1C", surf2:"#1B2A2D", ink:"#D7F5E6", ink2:"#A7C8BC", pri:"#6CFF9A", onpri:"#0A1112", priC:"#1F6640", onpriC:"#D7F5E6", sec:"#3E4E5E", onsec:"#D7F5E6", sec2:"#8AD0B0", bdg:"#8AD0B0", onbdg:"#0A1112", info:"#8AD0B0", outv:"#365047", ok:"#6CFF9A", err:"#CF6679", warn:"#FFC98A", sky1:"#1c4a5c", sky2:"#12333a", gnd:"#10241d", gnd2:"#0a1112" }, "ink-terminal-modern, phosphor green on near-black"),
  lcars: mkPal("LCARS Amber", { bg:"#120C1C", surf:"#1C132A", surf2:"#3D1F5C", ink:"#F3E9FF", ink2:"#D0B3E6", pri:"#F2A65A", onpri:"#120C1C", priC:"#CC7A2B", onpriC:"#120C1C", sec:"#A485F7", onsec:"#120C1C", sec2:"#C5678D", bdg:"#A485F7", onbdg:"#120C1C", info:"#C5678D", outv:"#4D2F5C", ok:"#F2A65A", err:"#CF6679", warn:"#FFC46B", sky1:"#3D1F5C", sky2:"#241338", gnd:"#1C132A", gnd2:"#120C1C" }, "lcars, amber + violet + mauve on aubergine"),
  lcars_blue: mkPal("LCARS Okuda Blue", { bg:"#0C0814", surf:"#161024", surf2:"#281E3D", ink:"#F0E6FF", ink2:"#C5B5E6", pri:"#5599FF", onpri:"#0C0814", priC:"#3366CC", onpriC:"#F0E6FF", sec:"#CC99FF", onsec:"#0C0814", sec2:"#FF9900", bdg:"#5599FF", onbdg:"#0C0814", info:"#CC99FF", outv:"#3D305C", ok:"#5599FF", err:"#FF4444", warn:"#FF9900", sky1:"#24305C", sky2:"#121838", gnd:"#181228", gnd2:"#0C0814" }, "lcars, Okuda ice blue + pale purple + gold on dark aubergine"),
  metro: mkPal("Metro Cyan", { bg:"#001A33", surf:"#002448", surf2:"#3D4854", ink:"#F0F8FF", ink2:"#B8CAD6", pri:"#00AEEF", onpri:"#001A33", priC:"#0070ca", onpriC:"#F0F8FF", sec:"#2D89EF", onsec:"#001A33", sec2:"#00AEEF", bdg:"#2D89EF", onbdg:"#001A33", info:"#00AEEF", outv:"#4D5A66", ok:"#00AEEF", err:"#CF6679", warn:"#FFC300", sky1:"#0a3a63", sky2:"#04263f", gnd:"#062033", gnd2:"#001a33" }, "windows-phone-metro, flat cyan on deep blue"),
  metro_zune: mkPal("Metro Zune Orange", { bg:"#181818", surf:"#242424", surf2:"#333333", ink:"#FFFFFF", ink2:"#CCCCCC", pri:"#D83B01", onpri:"#FFFFFF", priC:"#A02B00", onpriC:"#FFFFFF", sec:"#F0A30A", onsec:"#181818", sec2:"#E35900", bdg:"#D83B01", onbdg:"#FFFFFF", info:"#F0A30A", outv:"#444444", ok:"#D83B01", err:"#CF6679", warn:"#F0A30A", sky1:"#3a1a10", sky2:"#24120b", gnd:"#201510", gnd2:"#181818" }, "windows-phone-metro, Zune orange & mango on dark slate"),
  metro_magenta: mkPal("Metro Magenta", { bg:"#000000", surf:"#141414", surf2:"#282828", ink:"#FFFFFF", ink2:"#B3B3B3", pri:"#E0115F", onpri:"#FFFFFF", priC:"#A00040", onpriC:"#FFFFFF", sec:"#D80073", onsec:"#FFFFFF", sec2:"#E0115F", bdg:"#E0115F", onbdg:"#FFFFFF", info:"#E0115F", outv:"#404040", ok:"#E0115F", err:"#FF3366", warn:"#F0A30A", sky1:"#3a081a", sky2:"#1f040e", gnd:"#1a050d", gnd2:"#000000" }, "windows-phone-metro, Windows Phone magenta on pitch black"),
  aero: mkPal("Frutiger Aero", { bg:"#EAF7FF", surf:"#F7FCFF", surf2:"#DDF1FF", ink:"#173A52", ink2:"#34566E", pri:"#39B6F0", onpri:"#173A52", priC:"#A9E6FF", onpriC:"#173A52", sec:"#79D87E", onsec:"#173A52", sec2:"#0A6FA0", bdg:"#0A6FA0", onbdg:"#EAF7FF", info:"#0A6FA0", outv:"#A9C7DA", ok:"#0A6FA0", err:"#BA1A1A", warn:"#8A5A00", sky1:"#BEEBFF", sky2:"#DAF0FF", gnd:"#79D87E", gnd2:"#3f8f57" }, "frutiger-aero, sky and nature, light-first", true),
  navy: mkPal("Navy Gold", { bg:"#0A1630", surf:"#1A2645", surf2:"#2A3655", ink:"#E8E3D8", ink2:"#C9C4B9", pri:"#D4AF37", onpri:"#0A1630", priC:"#715f33", onpriC:"#E8E3D8", sec:"#4A90E2", onsec:"#0A1630", sec2:"#9C8970", bdg:"#4A90E2", onbdg:"#0A1630", info:"#4A90E2", outv:"#44483E", ok:"#D4AF37", err:"#CF6679", warn:"#E0B84C", sky1:"#16305c", sky2:"#0e1f3f", gnd:"#141f38", gnd2:"#0a1630" }, "navy-gold, metallic gold on navy"),
  paper: mkPal("Paper & Ink", { bg:"#F0F0EB", surf:"#FAF9F6", surf2:"#EBEAE4", ink:"#2C2C2C", ink2:"#454545", pri:"#2C2C2C", onpri:"#F0F0EB", priC:"#EBEAE4", onpriC:"#2C2C2C", sec:"#595959", onsec:"#F0F0EB", sec2:"#6B6B6B", bdg:"#2C2C2C", onbdg:"#F0F0EB", info:"#454545", outv:"#C9C9C9", ok:"#2C6B3F", err:"#BA1A1A", warn:"#8A5A00", sky1:"#d9d9d2", sky2:"#eceae3", gnd:"#cfcec6", gnd2:"#bfbeb6" }, "paper-ink, hueless, maximum legibility", true),
  deco: mkPal("Art Deco", { bg:"#0B0A0A", surf:"#141314", surf2:"#232124", ink:"#F3E8D0", ink2:"#C9BDA2", pri:"#D4AF37", onpri:"#0B0A0A", priC:"#977b2f", onpriC:"#0B0A0A", sec:"#F4E7CF", onsec:"#0B0A0A", sec2:"#B8A17A", bdg:"#B8A17A", onbdg:"#0B0A0A", info:"#B8A17A", outv:"#4B4332", ok:"#D4AF37", err:"#FFB4AB", warn:"#E0B84C", sky1:"#1d1a14", sky2:"#12100c", gnd:"#191712", gnd2:"#0b0a0a" }, "art-deco, gold hairlines on ivory-black"),
  noir: mkPal("Neo-Noir Neon", { bg:"#090A10", surf:"#111420", surf2:"#1C2130", ink:"#E7EAF7", ink2:"#B9C0D8", pri:"#aa43ff", onpri:"#090A10", priC:"#4B1D73", onpriC:"#E7EAF7", sec:"#00D1FF", onsec:"#090A10", sec2:"#FF3D9E", bdg:"#00D1FF", onbdg:"#090A10", info:"#00D1FF", outv:"#363D52", ok:"#00D1FF", err:"#FF6B6B", warn:"#FF3D9E", sky1:"#2a1140", sky2:"#12132a", gnd:"#141827", gnd2:"#090a10" }, "neo-noir-neon, violet and cyan glow"),
  emerald: mkPal("Emerald Silver", { bg:"#0D3B2E", surf:"#1A5544", surf2:"#2A6554", ink:"#E8F5E8", ink2:"#C9E4D9", pri:"#C0C0C0", onpri:"#0D3B2E", priC:"#505050", onpriC:"#E8F5E8", sec:"#50C878", onsec:"#0D3B2E", sec2:"#8BA888", bdg:"#50C878", onbdg:"#0D3B2E", info:"#50C878", outv:"#3E4E44", ok:"#50C878", err:"#CF6679", warn:"#E0B84C", sky1:"#14584a", sky2:"#0d3b2e", gnd:"#123f33", gnd2:"#0a2e24" }, "emerald-silver, silver on deep emerald"),
  amber: mkPal("Midnight Amber", { bg:"#0C1824", surf:"#15202E", surf2:"#253447", ink:"#E8EEF5", ink2:"#B8C5D6", pri:"#FFBF00", onpri:"#0C1824", priC:"#CC9900", onpriC:"#0C1824", sec:"#D4A76A", onsec:"#0C1824", sec2:"#D4A76A", bdg:"#D4A76A", onbdg:"#0C1824", info:"#D4A76A", outv:"#3D4854", ok:"#FFBF00", err:"#CF6679", warn:"#FFBF00", sky1:"#16324a", sky2:"#0c1824", gnd:"#132234", gnd2:"#0c1824" }, "midnight-amber, amber on midnight blue"),
  crimson: mkPal("Obsidian Crimson", { bg:"#0A0A0A", surf:"#141414", surf2:"#2D2D2D", ink:"#F5F5F5", ink2:"#D0D0D0", pri:"#DC143C", onpri:"#F5F5F5", priC:"#B00F30", onpriC:"#F5F5F5", sec:"#A8505A", onsec:"#F5F5F5", sec2:"#A8505A", bdg:"#A8505A", onbdg:"#F5F5F5", info:"#D0D0D0", outv:"#3D3D3D", ok:"#DC143C", err:"#FF6B6B", warn:"#DC143C", sky1:"#241014", sky2:"#12100f", gnd:"#1a1414", gnd2:"#0a0a0a" }, "obsidian-crimson, crimson on obsidian"),
  nouveau: mkPal("Art Nouveau", { bg:"#F6F0E6", surf:"#FFF8EE", surf2:"#E7D8C7", ink:"#2C2218", ink2:"#584638", pri:"#7B5737", onpri:"#F6F0E6", priC:"#D9C2A9", onpriC:"#2C2218", sec:"#769762", onsec:"#2C2218", sec2:"#C57C52", bdg:"#769762", onbdg:"#2C2218", info:"#C57C52", outv:"#CBB8A5", ok:"#6B8F57", err:"#BA1A1A", warn:"#C57C52", sky1:"#c4af99", sky2:"#fbf4ea", gnd:"#fcf6ec", gnd2:"#F6F0E6" }, "art-nouveau, organic curves, botanical accents, and decorative linework with a warm natural palette", true),
  aurora: mkPal("Aurora Glass Night", { bg:"#0A1224", surf:"#101C33", surf2:"#1D2B4A", ink:"#E7F0FF", ink2:"#B5C7E9", pri:"#6DE8FF", onpri:"#0A1224", priC:"#2A6F85", onpriC:"#E7F0FF", sec:"#8C7CFF", onsec:"#0A1224", sec2:"#7CFFD8", bdg:"#8C7CFF", onbdg:"#0A1224", info:"#7CFFD8", outv:"#334364", ok:"#8C7CFF", err:"#CF6679", warn:"#7CFFD8", sky1:"#2b4d6b", sky2:"#0d172c", gnd:"#0e192f", gnd2:"#0A1224" }, "aurora-glass-night, night-first glass aesthetic with aurora accents and disciplined blur"),
  burgundy: mkPal("Burgundy Rose Gold", { bg:"#2D0F1A", surf:"#3D1525", surf2:"#5C2A3D", ink:"#FFE6ED", ink2:"#E6C0CC", pri:"#B76E79", onpri:"#2D0F1A", priC:"#93575F", onpriC:"#FFE6ED", sec:"#4D1A2A", onsec:"#FFE6ED", sec2:"#C99BA5", bdg:"#4D1A2A", onbdg:"#FFE6ED", info:"#C99BA5", outv:"#6D3F4D", ok:"#4D1A2A", err:"#FFB4AB", warn:"#C99BA5", sky1:"#6c3648", sky2:"#351220", gnd:"#381322", gnd2:"#2D0F1A" }, "burgundy-rose-gold, rich burgundy with elegant rose gold metallic accents"),
  calm: mkPal("Calm Clinical", { bg:"#F5FAFD", surf:"#FFFFFF", surf2:"#E5EEF4", ink:"#1F394B", ink2:"#445F72", pri:"#38779e", onpri:"#F5FAFD", priC:"#C4DFF2", onpriC:"#1F394B", sec:"#61b48b", onsec:"#1F394B", sec2:"#7D9AB2", bdg:"#61b48b", onbdg:"#1F394B", info:"#7D9AB2", outv:"#B5C8D5", ok:"#4DAA7C", err:"#BA1A1A", warn:"#7D9AB2", sky1:"#aecadb", sky2:"#fafdfe", gnd:"#fcfefe", gnd2:"#F5FAFD" }, "calm-clinical, low-stress healthcare/admin palette with clear status readability", true),
  charcoal: mkPal("Charcoal Champagne", { bg:"#1F1F1F", surf:"#2A2A2A", surf2:"#3D3D3D", ink:"#F5F5F5", ink2:"#D0D0D0", pri:"#F7E7CE", onpri:"#1F1F1F", priC:"#C5B8A5", onpriC:"#1F1F1F", sec:"#3D3D3D", onsec:"#F5F5F5", sec2:"#D4C4A8", bdg:"#3D3D3D", onbdg:"#F5F5F5", info:"#D4C4A8", outv:"#4D4D4D", ok:"#3D3D3D", err:"#CF6679", warn:"#D4C4A8", sky1:"#5e5c57", sky2:"#252525", gnd:"#272727", gnd2:"#1F1F1F" }, "charcoal-champagne, sophisticated charcoal gray with warm champagne accents"),
  deep: mkPal("Deep Purple Platinum", { bg:"#1A0F2E", surf:"#24153D", surf2:"#3D2A5C", ink:"#F0EBFF", ink2:"#D0C0E6", pri:"#E5E4E2", onpri:"#1A0F2E", priC:"#B8B7B5", onpriC:"#1A0F2E", sec:"#2E1A50", onsec:"#F0EBFF", sec2:"#C8BFE0", bdg:"#2E1A50", onbdg:"#F0EBFF", info:"#C8BFE0", outv:"#4D3F6D", ok:"#2E1A50", err:"#CF6679", warn:"#C8BFE0", sky1:"#5b4b74", sky2:"#1f1236", gnd:"#211339", gnd2:"#1A0F2E" }, "deep-purple-platinum, deep purple background with luxurious platinum metallic accents"),
  forest: mkPal("Forest Copper", { bg:"#0D1F0D", surf:"#152915", surf2:"#2A4D2A", ink:"#E8F5E8", ink2:"#B8D9B8", pri:"#B87333", onpri:"#0D1F0D", priC:"#935E29", onpriC:"#E8F5E8", sec:"#1A3D1A", onsec:"#E8F5E8", sec2:"#8FA886", bdg:"#1A3D1A", onbdg:"#E8F5E8", info:"#8FA886", outv:"#3D5A3D", ok:"#1A3D1A", err:"#CF6679", warn:"#8FA886", sky1:"#44542c", sky2:"#112411", gnd:"#132613", gnd2:"#0D1F0D" }, "forest-copper, deep forest green with warm copper metallic accents"),
  rose: mkPal("Rose Gold", { bg:"#3D1F2B", surf:"#4D2F3B", surf2:"#5D3F4B", ink:"#F5E5E8", ink2:"#E5D5D8", pri:"#c1818b", onpri:"#3D1F2B", priC:"#7D4A52", onpriC:"#F5E5E8", sec:"#D4A5A5", onsec:"#3D1F2B", sec2:"#C9A9A9", bdg:"#D4A5A5", onbdg:"#3D1F2B", info:"#C9A9A9", outv:"#4E3A3E", ok:"#D4A5A5", err:"#FFB4AB", warn:"#C9A9A9", sky1:"#6d4753", sky2:"#452733", gnd:"#482a36", gnd2:"#3D1F2B" }, "rose-gold, warm and elegant rose gold with burgundy undertones"),
  royalb: mkPal("Royal Bronze", { bg:"#1A0A30", surf:"#220D40", surf2:"#3D1F5C", ink:"#F0E6FF", ink2:"#D0B3E6", pri:"#CD7F32", onpri:"#1A0A30", priC:"#975929", onpriC:"#F0E6FF", sec:"#2D1550", onsec:"#F0E6FF", sec2:"#9B7A5F", bdg:"#2D1550", onbdg:"#F0E6FF", info:"#9B7A5F", outv:"#4D2F5C", ok:"#2D1550", err:"#CF6679", warn:"#9B7A5F", sky1:"#573054", sky2:"#1e0c38", gnd:"#200c3b", gnd2:"#1A0A30" }, "royal-bronze, regal deep purple with luxurious bronze metallic accents"),
  royals: mkPal("Royal Silver", { bg:"#1A1535", surf:"#211A40", surf2:"#3D2F5C", ink:"#F0EBFF", ink2:"#C8BFE6", pri:"#C0C0C0", onpri:"#1A1535", priC:"#9A9A9A", onpriC:"#1A1535", sec:"#2A1F50", onsec:"#F0EBFF", sec2:"#A89BC9", bdg:"#2A1F50", onbdg:"#F0EBFF", info:"#A89BC9", outv:"#4D3F66", ok:"#2A1F50", err:"#CF6679", warn:"#A89BC9", sky1:"#55496e", sky2:"#1e183b", gnd:"#1f193d", gnd2:"#1A1535" }, "royal-silver, royal purple background with elegant silver metallic accents"),
  slatec: mkPal("Slate Cyan", { bg:"#1A1F24", surf:"#232930", surf2:"#3D4854", ink:"#E8F0F5", ink2:"#B8CAD6", pri:"#00D9FF", onpri:"#1A1F24", priC:"#00A8CC", onpriC:"#1A1F24", sec:"#2A333D", onsec:"#E8F0F5", sec2:"#6BA5B8", bdg:"#2A333D", onbdg:"#E8F0F5", info:"#6BA5B8", outv:"#4D5A66", ok:"#2A333D", err:"#CF6679", warn:"#6BA5B8", sky1:"#326273", sky2:"#1f242a", gnd:"#20262c", gnd2:"#1A1F24" }, "slate-cyan, cool modern slate gray with vibrant cyan metallic accents"),
  slateg: mkPal("Slate Gunmetal", { bg:"#1A2029", surf:"#232C38", surf2:"#3D4854", ink:"#E6ECF2", ink2:"#B8C5D6", pri:"#8F9CA8", onpri:"#1A2029", priC:"#7d8a94", onpriC:"#1A2029", sec:"#2D3844", onsec:"#E6ECF2", sec2:"#9DAAB6", bdg:"#2D3844", onbdg:"#E6ECF2", info:"#9DAAB6", outv:"#4D5A66", ok:"#2D3844", err:"#CF6679", warn:"#9DAAB6", sky1:"#4c5763", sky2:"#1f2631", gnd:"#202834", gnd2:"#1A2029" }, "slate-gunmetal, industrial slate gray with gunmetal metallic accents"),
  solarpunk: mkPal("Solarpunk Civic", { bg:"#F2FBF4", surf:"#FBFFFC", surf2:"#E2F2E8", ink:"#1E3A27", ink2:"#456355", pri:"#38B56A", onpri:"#1E3A27", priC:"#BFEFD0", onpriC:"#1E3A27", sec:"#4FAEEA", onsec:"#1E3A27", sec2:"#F2C46C", bdg:"#4FAEEA", onbdg:"#1E3A27", info:"#F2C46C", outv:"#B3D0BF", ok:"#4FAEEA", err:"#BA1A1A", warn:"#F2C46C", sky1:"#acdec0", sky2:"#f7fdf8", gnd:"#f8fefa", gnd2:"#F2FBF4" }, "solarpunk-civic, optimistic civic palette with daylight greens and trust-building clarity", true),
};

const LEGACY_PALETTES = {
  ink: { name: "Ink Terminal", nav: "TABS", font: '"JetBrains Mono","IBM Plex Mono",monospace', dfont: '"JetBrains Mono",monospace',
    v: { bg:"#0A1112", surf:"#101A1C", surf2:"#1B2A2D", ink:"#D7F5E6", ink2:"#A7C8BC", pri:"#6CFF9A", onpri:"#03240F", priC:"#1F6640", onpriC:"#D7FFE4",
         sec:"#3E4E5E", onsec:"#EAF3FF", sec2:"#8AD0B0", bdg:"#8AD0B0", onbdg:"#0E3021", info:"#8AD0B0", outv:"#365047", ok:"#6CFF9A", err:"#CF6679", warn:"#FFC98A",
         rs:"4px", rl:"8px", rp:"4px", navr:"4px", pad:"12px", tls:".26em", sky1:"#1c4a5c", sky2:"#12333a", gnd:"#10241d", gnd2:"#0a1112" },
    note: "Ktheme ink-terminal-modern: JetBrains Mono, #6CFF9A on #0A1112, sharp 4px corners, bottom tabs. Closest to the app today, contrast raised to AA." },
  rail: { name: "Rail Console", nav: "SWEEP", font: '"Antonio","Jost",sans-serif', dfont: '"Antonio",sans-serif',
    v: { bg:"#120C1C", surf:"#1C132A", surf2:"#3D1F5C", ink:"#F3E9FF", ink2:"#D0B3E6", pri:"#F2A65A", onpri:"#1B0E24", priC:"#CC7A2B", onpriC:"#FFE6CC",
         sec:"#A485F7", onsec:"#170F2E", sec2:"#C5678D", bdg:"#A485F7", onbdg:"#170F2E", info:"#C5678D", outv:"#4D2F5C", ok:"#F2A65A", err:"#CF6679", warn:"#FFC46B",
         rs:"999px", rl:"28px", rp:"22px", navr:"0 999px 999px 0", pad:"10px", tls:".16em", sky1:"#3D1F5C", sky2:"#241338", gnd:"#1C132A", gnd2:"#120C1C" },
    note: "Sweep-rail console built to the LCARS manifesto's own rules: the swept elbow is the whole frame, rail segments ARE the buttons (never separate ones), frame thickness changes at every turn, rounded caps terminate each bar, labels sit bottom-right, three hues + tints only, no gradients, no borders — fills alone. Ktheme lcars tokens (#F2A65A amber, #A485F7 violet, #C5678D mauve); original geometry, no franchise marks." },
  metro: { name: "Metro Tiles", nav: "TILES", font: '"Open Sans","Nunito Sans",sans-serif', dfont: '"Open Sans",sans-serif',
    v: { bg:"#001A33", surf:"#002448", surf2:"#3D4854", ink:"#F0F8FF", ink2:"#B8CAD6", pri:"#00AEEF", onpri:"#00151F", priC:"#0078D7", onpriC:"#E8F7FF",
         sec:"#2D89EF", onsec:"#001021", sec2:"#00AEEF", bdg:"#2D89EF", onbdg:"#FFFFFF", info:"#00AEEF", outv:"#4D5A66", ok:"#00AEEF", err:"#CF6679", warn:"#FFC300",
         rs:"0px", rl:"0px", rp:"0px", navr:"0px", pad:"14px", tls:"0em", sky1:"#0a3a63", sky2:"#04263f", gnd:"#062033", gnd2:"#001a33" },
    note: "Ktheme windows-phone-metro: flat #00AEEF on #001A33, zero radius, spacious 1.25 scale, light-weight Open Sans, pivot titles and a tile nav strip." },
  aero: { name: "Frutiger Aero", nav: "TABS", font: '"Nunito Sans",sans-serif', dfont: '"Nunito Sans",sans-serif',
    v: { bg:"#EAF7FF", surf:"#F7FCFF", surf2:"#DDF1FF", ink:"#173A52", ink2:"#34566E", pri:"#39B6F0", onpri:"#022A40", priC:"#A9E6FF", onpriC:"#00314D",
         sec:"#79D87E", onsec:"#07350D", sec2:"#0A6FA0", bdg:"#0A6FA0", onbdg:"#FFFFFF", info:"#0A6FA0", outv:"#A9C7DA", ok:"#0A6FA0", err:"#BA1A1A", warn:"#8A5A00",
         rs:"12px", rl:"18px", rp:"16px", navr:"12px", pad:"14px", tls:".06em", sky1:"#BEEBFF", sky2:"#DAF0FF", gnd:"#79D87E", gnd2:"#3f8f57" },
    note: "Ktheme frutiger-aero: light glossy #EAF7FF ground, #39B6F0 sky primary, 12–18px rounded, glass panels, comfortable 1.1 scale. The only light-first skin with a green horizon in the 3D view." },
  navy: { name: "Navy Gold", nav: "RAIL", font: '"Jost",system-ui,sans-serif', dfont: '"Jost",sans-serif',
    v: { bg:"#0A1630", surf:"#1A2645", surf2:"#2A3655", ink:"#E8E3D8", ink2:"#C9C4B9", pri:"#D4AF37", onpri:"#0A1630", priC:"#856D34", onpriC:"#FFF8DC",
         sec:"#4A90E2", onsec:"#FFFFFF", sec2:"#9C8970", bdg:"#4A90E2", onbdg:"#FFFFFF", info:"#4A90E2", outv:"#44483E", ok:"#D4AF37", err:"#CF6679", warn:"#E0B84C",
         rs:"8px", rl:"14px", rp:"10px", navr:"8px", pad:"13px", tls:".14em", sky1:"#16305c", sky2:"#0e1f3f", gnd:"#141f38", gnd2:"#0a1630" },
    note: "Ktheme navy-gold: #D4AF37 metallic accent on #0A1630, 8px radius, elevated panels, Jost. Rail nav on tablet; the accent is used sparingly as a hairline and label colour." },
  paper: { name: "Paper & Ink", nav: "TABS", font: '"Source Serif 4",Georgia,serif', dfont: '"Jost",sans-serif',
    v: { bg:"#F0F0EB", surf:"#FAF9F6", surf2:"#EBEAE4", ink:"#2C2C2C", ink2:"#454545", pri:"#2C2C2C", onpri:"#FAF9F6", priC:"#EBEAE4", onpriC:"#2C2C2C",
         sec:"#595959", onsec:"#FAF9F6", sec2:"#6B6B6B", bdg:"#2C2C2C", onbdg:"#FAF9F6", info:"#454545", outv:"#C9C9C9", ok:"#2C6B3F", err:"#BA1A1A", warn:"#8A5A00",
         rs:"2px", rl:"6px", rp:"3px", navr:"2px", pad:"14px", tls:".1em", sky1:"#d9d9d2", sky2:"#eceae3", gnd:"#cfcec6", gnd2:"#bfbeb6" },
    note: "Ktheme paper-ink: no colour at all — #2C2C2C on #F0F0EB, serif body, 2px corners. This is the accessibility / bright-sunlight skin; every state reads as weight and rule, not hue." },
  deco: { name: "Art Deco", nav: "RAIL", font: '"Jost",sans-serif', dfont: '"Jost",sans-serif',
    v: { bg:"#0B0A0A", surf:"#141314", surf2:"#232124", ink:"#F3E8D0", ink2:"#C9BDA2", pri:"#D4AF37", onpri:"#1A1405", priC:"#8F7121", onpriC:"#FFF2C6",
         sec:"#F4E7CF", onsec:"#221A0A", sec2:"#B8A17A", bdg:"#B8A17A", onbdg:"#161005", info:"#B8A17A", outv:"#4B4332", ok:"#D4AF37", err:"#FFB4AB", warn:"#E0B84C",
         rs:"0px", rl:"0px", rp:"0px", navr:"0px", pad:"11px", tls:".35em", sky1:"#1d1a14", sky2:"#12100c", gnd:"#191712", gnd2:"#0b0a0a" },
    note: "Ktheme art-deco: gold hairlines on #0B0A0A, sharp corners, 0.35em tracking, compact 0.94 scale, geometric Jost caps. Rules replace fills; the rail becomes a stepped column." },
};

const FAMILIES = [
  { name: "TERMINAL & NEON", keys: ["ink", "noir", "metro", "metro_zune", "metro_magenta", "aurora", "slatec"] },
  { name: "CONSOLE & AMBER", keys: ["lcars", "lcars_blue", "amber", "royalb", "forest", "crimson"] },
  { name: "METAL & JEWEL",   keys: ["navy", "deco", "emerald", "royals", "deep", "charcoal", "slateg", "rose", "burgundy"] },
  { name: "DAYLIGHT",        keys: ["aero", "paper", "nouveau", "calm", "solarpunk"] },
];

// Generate PK dictionary for Cleverferret verify_contrast.js
const cleanHex = (h) => (h || "").replace("#", "").trim();

const PK = {};
for (const [key, p] of Object.entries(PALETTES)) {
  const c = p.c;
  // Order expected by verify_contrast.js:
  // bg surf surf2 ink ink2 pri onpri priC onpriC sec sec2 outv err
  const roles = [c.bg, c.surf, c.surf2, c.ink, c.ink2, c.pri, c.onpri, c.priC, c.onpriC, c.sec, c.sec2, c.outv, c.err];
  const hexString = roles.map(cleanHex).join(" ");
  const entry = [p.name, hexString];
  if (p.light) entry.push(1);
  PK[key] = entry;
}

// THEME_DESKTOP_CONFIGS dictionary
const THEME_DESKTOP_CONFIGS = {
  "lcars": {
    "windowChrome": { "titleBarHeight": 28, "headerStyle": "lcars-elbow", "cornerStyle": "pill", "panelRadius": 22, "controlRadius": 999, "borderWidth": 1, "shadow": "0 16px 44px rgba(0, 0, 0, 0.65)" },
    "menuBar": { "height": 28, "fontSize": 11, "letterSpacing": "0.12em", "textTransform": "uppercase", "dropdownRadius": 12, "dropdownShadow": "0 14px 34px rgba(0,0,0,.65)" },
    "taskbar": { "height": 40, "buttonRadius": 999, "dockAlignment": "left", "quickChatBorderRadius": 999 },
    "cameraHud": { "panelRadius": 16, "buttonRadius": 999, "shadow": "0 8px 24px rgba(0,0,0,0.5)" },
    "sweep": { "elbowWidth": 36, "titleCapRadius": "999px", "accentBand": "primary", "showElbowBar": true }
  },
  "frutiger-aero": {
    "windowChrome": { "titleBarHeight": 26, "headerStyle": "glass", "cornerStyle": "rounded", "panelRadius": 16, "controlRadius": 12, "borderWidth": 1, "backdropBlur": 12, "shadow": "0 12px 32px rgba(0, 80, 140, 0.22)" },
    "menuBar": { "height": 28, "fontSize": 11, "letterSpacing": "0.06em", "textTransform": "none", "dropdownRadius": 12, "dropdownShadow": "0 10px 28px rgba(0, 60, 120, 0.25)" },
    "taskbar": { "height": 40, "buttonRadius": 12, "dockAlignment": "left", "quickChatBorderRadius": 12 },
    "cameraHud": { "panelRadius": 16, "buttonRadius": 10, "shadow": "0 8px 20px rgba(0, 60, 120, 0.2)" },
    "sweep": { "elbowWidth": 28, "titleCapRadius": "18px", "accentBand": "secondary", "showElbowBar": true }
  },
  "art-deco": {
    "windowChrome": { "titleBarHeight": 26, "headerStyle": "geometric-stepped", "cornerStyle": "sharp", "panelRadius": 0, "controlRadius": 0, "borderWidth": 1, "shadow": "0 16px 40px rgba(0, 0, 0, 0.75)" },
    "menuBar": { "height": 28, "fontSize": 11, "letterSpacing": "0.18em", "textTransform": "uppercase", "dropdownRadius": 0, "dropdownShadow": "0 14px 30px rgba(0,0,0,.7)" },
    "taskbar": { "height": 40, "buttonRadius": 0, "dockAlignment": "left", "quickChatBorderRadius": 0 },
    "cameraHud": { "panelRadius": 0, "buttonRadius": 0, "shadow": "0 8px 24px rgba(0,0,0,0.6)" },
    "sweep": { "elbowWidth": 30, "titleCapRadius": "0px", "accentBand": "primary", "showElbowBar": true }
  },
  "windows-phone-metro": {
    "windowChrome": { "titleBarHeight": 26, "headerStyle": "flat", "cornerStyle": "sharp", "panelRadius": 0, "controlRadius": 0, "borderWidth": 1, "shadow": "0 10px 24px rgba(0, 0, 0, 0.45)" },
    "menuBar": { "height": 28, "fontSize": 11, "letterSpacing": "0.02em", "textTransform": "lowercase", "dropdownRadius": 0, "dropdownShadow": "0 10px 24px rgba(0, 0, 0, 0.45)" },
    "taskbar": { "height": 40, "buttonRadius": 0, "dockAlignment": "left", "quickChatBorderRadius": 0 },
    "cameraHud": { "panelRadius": 0, "buttonRadius": 0, "shadow": "0 6px 18px rgba(0, 0, 0, 0.4)" },
    "sweep": { "elbowWidth": 26, "titleCapRadius": "0px", "accentBand": "primary", "showElbowBar": false }
  },
  "ink-terminal-modern": {
    "windowChrome": { "titleBarHeight": 26, "headerStyle": "terminal-bar", "cornerStyle": "sharp", "panelRadius": 4, "controlRadius": 4, "borderWidth": 1, "shadow": "0 12px 32px rgba(0, 0, 0, 0.6)" },
    "menuBar": { "height": 28, "fontSize": 11, "letterSpacing": "0.1em", "textTransform": "uppercase", "dropdownRadius": 4, "dropdownShadow": "0 12px 30px rgba(0, 0, 0, 0.6)" },
    "taskbar": { "height": 40, "buttonRadius": 4, "dockAlignment": "left", "quickChatBorderRadius": 4 },
    "cameraHud": { "panelRadius": 4, "buttonRadius": 4, "shadow": "0 8px 20px rgba(0, 0, 0, 0.5)" },
    "sweep": { "elbowWidth": 28, "titleCapRadius": "4px", "accentBand": "primary", "showElbowBar": true }
  },
  "paper-ink": {
    "windowChrome": { "titleBarHeight": 26, "headerStyle": "editorial", "cornerStyle": "quiet", "panelRadius": 3, "controlRadius": 2, "borderWidth": 1, "shadow": "0 6px 16px rgba(0, 0, 0, 0.15)" },
    "menuBar": { "height": 28, "fontSize": 11, "letterSpacing": "0.08em", "textTransform": "none", "dropdownRadius": 3, "dropdownShadow": "0 8px 20px rgba(0, 0, 0, 0.15)" },
    "taskbar": { "height": 40, "buttonRadius": 2, "dockAlignment": "left", "quickChatBorderRadius": 2 },
    "cameraHud": { "panelRadius": 3, "buttonRadius": 2, "shadow": "0 4px 12px rgba(0, 0, 0, 0.12)" },
    "sweep": { "elbowWidth": 26, "titleCapRadius": "3px", "accentBand": "primary", "showElbowBar": true }
  }
};

const _buildDefaultDesktopConfig = (data) => {
  const dark = data.darkMode !== false;
  const corner = data.adaptation?.layout?.cornerStyle || "rounded";
  const nav = data.adaptation?.layout?.navigationStyle || "tabs";

  let pr = 10, cr = 8, cap = "10px";
  if (corner === "pill") { pr = 18; cr = 999; cap = "999px"; }
  else if (corner === "sharp") { pr = 0; cr = 0; cap = "0px"; }

  return {
    windowChrome: {
      titleBarHeight: 26,
      headerStyle: nav === "rail" ? "lcars-elbow" : "standard",
      cornerStyle: corner,
      panelRadius: pr,
      controlRadius: cr,
      borderWidth: 1,
      shadow: dark ? "0 14px 36px rgba(0,0,0,0.5)" : "0 10px 26px rgba(0,0,0,0.2)"
    },
    menuBar: {
      height: 28,
      fontSize: 11,
      letterSpacing: "0.06em",
      textTransform: dark ? "uppercase" : "none",
      dropdownRadius: pr,
      dropdownShadow: dark ? "0 12px 28px rgba(0,0,0,0.4)" : "0 8px 20px rgba(0,0,0,0.18)"
    },
    taskbar: {
      height: 40,
      buttonRadius: cr,
      dockAlignment: "left",
      quickChatBorderRadius: cr
    },
    cameraHud: {
      panelRadius: pr,
      buttonRadius: cr,
      shadow: "0 8px 20px rgba(0,0,0,0.3)"
    },
    sweep: {
      elbowWidth: 30,
      titleCapRadius: cap,
      accentBand: "primary",
      showElbowBar: true
    }
  };
};

// Write dist/index.js (ESM)
const esmContent = `// @ktheme/tokens ESM bundle
export const PALETTES = ${JSON.stringify(PALETTES, null, 2)};
export const LEGACY_PALETTES = ${JSON.stringify(LEGACY_PALETTES, null, 2)};
export const FAMILIES = ${JSON.stringify(FAMILIES, null, 2)};
export const PK = ${JSON.stringify(PK, null, 2)};
export const THEME_DESKTOP_CONFIGS = ${JSON.stringify(THEME_DESKTOP_CONFIGS, null, 2)};

export function buildDefaultDesktopConfig(data) {
  const dark = data.darkMode !== false;
  const corner = data.adaptation?.layout?.cornerStyle || "rounded";
  const nav = data.adaptation?.layout?.navigationStyle || "tabs";

  let pr = 10, cr = 8, cap = "10px";
  if (corner === "pill") { pr = 18; cr = 999; cap = "999px"; }
  else if (corner === "sharp") { pr = 0; cr = 0; cap = "0px"; }

  return {
    windowChrome: {
      titleBarHeight: 26,
      headerStyle: nav === "rail" ? "lcars-elbow" : "standard",
      cornerStyle: corner,
      panelRadius: pr,
      controlRadius: cr,
      borderWidth: 1,
      shadow: dark ? "0 14px 36px rgba(0,0,0,0.5)" : "0 10px 26px rgba(0,0,0,0.2)"
    },
    menuBar: {
      height: 28,
      fontSize: 11,
      letterSpacing: "0.06em",
      textTransform: dark ? "uppercase" : "none",
      dropdownRadius: pr,
      dropdownShadow: dark ? "0 12px 28px rgba(0,0,0,0.4)" : "0 8px 20px rgba(0,0,0,0.18)"
    },
    taskbar: {
      height: 40,
      buttonRadius: cr,
      dockAlignment: "left",
      quickChatBorderRadius: cr
    },
    cameraHud: {
      panelRadius: pr,
      buttonRadius: cr,
      shadow: "0 8px 20px rgba(0,0,0,0.3)"
    },
    sweep: {
      elbowWidth: 30,
      titleCapRadius: cap,
      accentBand: "primary",
      showElbowBar: true
    }
  };
}
`;
fs.writeFileSync(path.join(distDir, 'index.js'), esmContent, 'utf8');

// Write dist/index.cjs (CommonJS)
const cjsContent = `// @ktheme/tokens CommonJS bundle
const PALETTES = ${JSON.stringify(PALETTES, null, 2)};
const LEGACY_PALETTES = ${JSON.stringify(LEGACY_PALETTES, null, 2)};
const FAMILIES = ${JSON.stringify(FAMILIES, null, 2)};
const PK = ${JSON.stringify(PK, null, 2)};
const THEME_DESKTOP_CONFIGS = ${JSON.stringify(THEME_DESKTOP_CONFIGS, null, 2)};

function buildDefaultDesktopConfig(data) {
  const dark = data.darkMode !== false;
  const corner = data.adaptation?.layout?.cornerStyle || "rounded";
  const nav = data.adaptation?.layout?.navigationStyle || "tabs";

  let pr = 10, cr = 8, cap = "10px";
  if (corner === "pill") { pr = 18; cr = 999; cap = "999px"; }
  else if (corner === "sharp") { pr = 0; cr = 0; cap = "0px"; }

  return {
    windowChrome: {
      titleBarHeight: 26,
      headerStyle: nav === "rail" ? "lcars-elbow" : "standard",
      cornerStyle: corner,
      panelRadius: pr,
      controlRadius: cr,
      borderWidth: 1,
      shadow: dark ? "0 14px 36px rgba(0,0,0,0.5)" : "0 10px 26px rgba(0,0,0,0.2)"
    },
    menuBar: {
      height: 28,
      fontSize: 11,
      letterSpacing: "0.06em",
      textTransform: dark ? "uppercase" : "none",
      dropdownRadius: pr,
      dropdownShadow: dark ? "0 12px 28px rgba(0,0,0,0.4)" : "0 8px 20px rgba(0,0,0,0.18)"
    },
    taskbar: {
      height: 40,
      buttonRadius: cr,
      dockAlignment: "left",
      quickChatBorderRadius: cr
    },
    cameraHud: {
      panelRadius: pr,
      buttonRadius: cr,
      shadow: "0 8px 20px rgba(0,0,0,0.3)"
    },
    sweep: {
      elbowWidth: 30,
      titleCapRadius: cap,
      accentBand: "primary",
      showElbowBar: true
    }
  };
}

module.exports = {
  PALETTES,
  LEGACY_PALETTES,
  FAMILIES,
  PK,
  THEME_DESKTOP_CONFIGS,
  buildDefaultDesktopConfig
};
`;
fs.writeFileSync(path.join(distDir, 'index.cjs'), cjsContent, 'utf8');

// Write dist/index.d.ts (TypeScript declarations)
const dtsContent = `export interface PaletteColorRoles {
  bg: string;
  surf: string;
  surf2: string;
  ink: string;
  ink2: string;
  pri: string;
  onpri: string;
  priC: string;
  onpriC: string;
  sec: string;
  onsec: string;
  sec2: string;
  bdg: string;
  onbdg: string;
  info: string;
  outv: string;
  ok: string;
  err: string;
  warn: string;
  sky1: string;
  sky2: string;
  gnd: string;
  gnd2: string;
}

export interface PaletteEntry {
  name: string;
  note: string;
  light: boolean;
  c: PaletteColorRoles;
}

export declare const PALETTES: Record<string, PaletteEntry>;
export declare const LEGACY_PALETTES: Record<string, any>;
export declare const FAMILIES: Array<{ name: string; keys: string[] }>;
export declare const PK: Record<string, [string, string, number?]>;
export declare const THEME_DESKTOP_CONFIGS: Record<string, any>;
export declare function buildDefaultDesktopConfig(data: any): any;
`;
fs.writeFileSync(path.join(distDir, 'index.d.ts'), dtsContent, 'utf8');

// Write dist/tokens.json and individual JSON files in dist/json/
const themeExamplesDir = path.resolve(kthemeRoot, 'themes/examples');
const tokensJsonObject = {
  palettes: PALETTES,
  desktopConfigs: THEME_DESKTOP_CONFIGS,
  themes: {}
};

if (fs.existsSync(themeExamplesDir)) {
  const exampleFiles = fs.readdirSync(themeExamplesDir).filter(f => f.endsWith('.json'));
  for (const file of exampleFiles) {
    const srcPath = path.join(themeExamplesDir, file);
    const destPath = path.join(jsonDistDir, file);
    const raw = fs.readFileSync(srcPath, 'utf8');
    fs.writeFileSync(destPath, raw, 'utf8');
    try {
      const parsed = JSON.parse(raw);
      const themeId = parsed.metadata?.id || file.replace('.json', '');
      tokensJsonObject.themes[themeId] = parsed;
    } catch (e) {
      // ignore non-JSON or malformed
    }
  }
}

fs.writeFileSync(path.join(distDir, 'tokens.json'), JSON.stringify(tokensJsonObject, null, 2), 'utf8');

// Generate CSS custom properties in dist/tokens.css
let cssContent = `/* Ktheme Centralized Tokens CSS */\n:root {\n`;
for (const [palKey, pal] of Object.entries(PALETTES)) {
  for (const [role, val] of Object.entries(pal.c)) {
    cssContent += `  --ktheme-${palKey}-${role}: ${val};\n`;
  }
}
cssContent += `}\n`;
fs.writeFileSync(path.join(distDir, 'tokens.css'), cssContent, 'utf8');

// Requirement 5: Synchronize JSON assets to runtime directory (libs/ktheme-runtime/src/main/resources/themes/)
if (fs.existsSync(runtimeThemesDir)) {
  console.log(`[build-tokens] Synchronizing theme JSON assets to ${runtimeThemesDir}...`);
  if (fs.existsSync(jsonDistDir)) {
    const jsonFiles = fs.readdirSync(jsonDistDir).filter(f => f.endsWith('.json'));
    for (const file of jsonFiles) {
      const srcPath = path.join(jsonDistDir, file);
      const destPath = path.join(runtimeThemesDir, file);
      fs.copyFileSync(srcPath, destPath);
    }
    // Update index.txt
    const allRuntimeJson = fs.readdirSync(runtimeThemesDir).filter(f => f.endsWith('.json')).sort();
    fs.writeFileSync(path.join(runtimeThemesDir, 'index.txt'), allRuntimeJson.join('\n') + '\n', 'utf8');
    console.log(`[build-tokens] Synchronized ${jsonFiles.length} theme files to runtime directory.`);
  }
}

console.log('[build-tokens] @ktheme/tokens build completed successfully!');
